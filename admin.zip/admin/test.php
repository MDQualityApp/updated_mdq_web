<?php
$mysqli = new mysqli("localhost", "root", "", "updated_mdq");

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Retrieve all $table2Ids from your_table1 (replace 'your_table1' and 'your_column' with your actual table and column names)
$sqlTable1 = "SELECT id FROM application_web";
$resultTable1 = $mysqli->query($sqlTable1);

if (!$resultTable1) {
    // Query failed, display the error and exit
    echo "Error in query: " . $mysqli->error;
    exit();
}

if ($resultTable1->num_rows > 0) {
    while ($rowTable1 = $resultTable1->fetch_assoc()) {
        $table2Id = $rowTable1['id'];
        echo $table2Id;

        // Retrieve the row from application_web using the obtained $table2Id
        $sqlApplicationWeb = "SELECT * FROM application_web WHERE id = $table2Id";
        $resultApplicationWeb = $mysqli->query($sqlApplicationWeb);

        if ($resultApplicationWeb->num_rows > 0) {
            $rowApplicationWeb = $resultApplicationWeb->fetch_assoc();

            // Get foreign key IDs as an array
            $foreignKeysArray = explode(',', $rowApplicationWeb['technology']);

            // Use the foreign key IDs as needed
            foreach ($foreignKeysArray as $foreignKeyId) {
                // Retrieve data from technology_name using $foreignKeyId
                $sqlTable1 = "SELECT technology FROM technology_name WHERE id = '$foreignKeyId'";
                $resultTable1 = $mysqli->query($sqlTable1);

                if (!$resultTable1) {
                    // Query failed, display the error and exit
                    echo "Error in query: " . $mysqli->error;
                    exit();
                }

                if ($resultTable1->num_rows > 0) {
                    $rowTable1 = $resultTable1->fetch_assoc();
                    // Access data from technology_name, for example, $rowTable1['technology']
                    echo implode(',', $rowTable1) . ',';
                }
            }
        } else {
            echo "No results found in application_web for ID $table2Id";
        }
    }
} else {
    echo "No results found in your_table1";
}

$mysqli->close();
?>
