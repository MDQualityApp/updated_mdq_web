<?php
include '../connect.php';

if(isset($_POST['edit-post'])){
    $post_id = $_POST['id'];
    $folder="../images/portfolio/";

    // Fetch the existing photos from the database
    $result = mysqli_query($conn, "SELECT photos FROM application_web WHERE id = '$post_id'");
    $row = mysqli_fetch_assoc($result);
    $existingPhotos = $row['photos'];

    // Process new photos
    $newPhotos = "";
    foreach ($_FILES["photos"]["error"] as $key => $error) {
        if ($error == UPLOAD_ERR_OK) {
            $tmp_name = $_FILES["photos"]["tmp_name"][$key];
            $name = $_FILES["photos"]["name"][$key];
            $newPhotos = $newPhotos . "," . $name;

            if (!move_uploaded_file($tmp_name, $folder . $name)) {
                echo "<script type='text/javascript'>
                    alert('Failed to move uploaded files');
                    window.location.href='table-add-mobile.php';
                </script>";
                exit;
            }
        }
    }

    // Combine existing and new photos
    $allPhotos = $existingPhotos . $newPhotos;

    $logo_images = $_FILES["logo_images"]["name"];
    $projectimagesTempname = $_FILES["logo_images"]["tmp_name"];

    $banner_images = $_FILES["banner_images"]["name"];
    $bannerimagesTempname = $_FILES["banner_images"]["tmp_name"];

    $project_overview = $_POST["project_overview"];
    $project_title = $_POST["project_title"];

    if (!move_uploaded_file($projectimagesTempname, $folder . $logo_images) || !move_uploaded_file($bannerimagesTempname, $folder . $banner_images)) {
        echo "<script type='text/javascript'>
            alert('Failed to move uploaded files');
            window.location.href='table-add-mobile.php';
        </script>";
        exit;
    }

    $cilent_id = $_POST['cilent_id'];
    $technologys = $_POST['technology'];
    $technology = implode(",", $technologys);

    // Update the database with all photos and other fields
    $sql = mysqli_query($conn, "UPDATE application_web SET cilent_id = IF(LENGTH('$cilent_id')=0, cilent_id, '$cilent_id'), technology = IF(LENGTH('$technology')=0, technology, '$technology'), photos = IF(LENGTH('$allPhotos')=0, photos, '$allPhotos'), project_overview = IF(LENGTH('$project_overview')=0, project_overview,'$project_overview'), project_title = IF(LENGTH('$project_title')=0, project_title, '$project_title'), logo_images = IF(LENGTH('$logo_images')=0, logo_images, '$logo_images'), banner_images = IF(LENGTH('$banner_images')=0, banner_images, '$banner_images') WHERE id = '$post_id'");

    if($sql){
        echo "<script type='text/javascript'>
            alert('Application has been updated successfully');
            window.location.href='table-add-mobile.php';
        </script>";
    } else {
        echo "<script type='text/javascript'>
            alert('Failed to update application');
            window.location.href='table-add-mobile.php';
        </script>";
    }
}
?>
